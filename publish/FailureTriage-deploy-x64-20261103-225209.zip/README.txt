Failure Triage - IIS deployment bundle

1. Copy and unzip this bundle on the server, then open an elevated PowerShell in the unzipped folder.
2. Install the prerequisites (IIS + ASP.NET Core 9 Hosting Bundle; skip if already present):
     .\install-prereqs.ps1 -OpenFirewallPort 5050
   (needs internet access, or pass -HostingBundleInstaller <path to dotnet-hosting-9.x-win.exe>; restart if it asks you to)
3. Deploy:
     .\deploy-iis.ps1 -EnvVars @{ ANTHROPIC_API_KEY = '<key>'; ADMIN_PASSWORD = '<strong password>' }
   Site: http://localhost:5050/ (change with -Port / -HostName). Re-run the same command to update in place.
   Run "Get-Help .\deploy-iis.ps1 -Full" for all options (Jira settings, data folder, site name).
